#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <limits> // Added for std::numeric_limits

// --- REQUIRED EXTERNAL LIBRARIES ---
// Since CMake configuration sets the include path, we can use the standard include style:
#include <curl/curl-8.11.0_2-win64-mingw/include/curl/curl.h>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

// --- Global Constants and Structures ---

// NWS requires a User-Agent identifying the application and contact info
const std::string USER_AGENT = "WeatherFinderApp/1.0 (canvas-simulation@google.com)";

// *** WORKING ABSOLUTE PATH FOR CERTIFICATE FILE ***
// This path is taken from your last query and should be correct for your environment.
const std::string CERT_FILE_PATH = "C:/Program Files/JetBrains/CLion 2025.2/bin/mingw/include/curl/curl-8.11.0_2-win64-mingw/bin/curl-ca-bundle.crt";

// A simple structure to hold the coordinates returned by Geocoding (OpenStreetMap)
struct Coordinates {
    double latitude = 0.0;
    double longitude = 0.0;
    std::string displayName = "";
};

// A structure to represent a single forecast period (NWS)
struct ForecastPeriod {
    std::string name;
    int temperature;
    std::string detailedForecast;
    std::string iconUrl; // Retained in struct but not displayed in console output
};

// --- libcurl Helper Functions ---

// Callback function used by libcurl to write the response data into a std::string
size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

// Generic function to fetch a URL and return the response body as a string.
std::string fetchUrl(const std::string& url) {
    CURL *curl;
    CURLcode res;
    std::string readBuffer;

    curl = curl_easy_init();

    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        // Set up the function and buffer to write the response body
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        // Required User-Agent header for both Nominatim and NWS
        curl_easy_setopt(curl, CURLOPT_USERAGENT, USER_AGENT.c_str());
        // Follow redirects (NWS often redirects from /points to the actual grid endpoint)
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

        // Tell curl where to find the trusted root certificates for HTTPS
        curl_easy_setopt(curl, CURLOPT_CAINFO, CERT_FILE_PATH.c_str());

        res = curl_easy_perform(curl);

        if (res != CURLE_OK) {
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
            readBuffer.clear(); // Clear the buffer on error
        } else {
            long http_code = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
            if (http_code < 200 || http_code >= 300) {
                 std::cerr << "HTTP request failed with status code: " << http_code << " for URL: " << url << std::endl;
                 readBuffer.clear(); // Clear the buffer on non-2xx code
            }
        }

        curl_easy_cleanup(curl);
    } else {
        std::cerr << "Error: Could not initialize libcurl." << std::endl;
    }

    return readBuffer;
}

// --- API Implementation Functions (Unchanged Logic) ---

// Step 1: Geocoding (City Name to Coordinates) using Nominatim
Coordinates getCityCoordinates(const std::string& city) {
    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "--- 1. Calling OpenStreetMap Nominatim API for: " << city << " ---\n";

    std::string encodedCity;
    CURL *curl = curl_easy_init();
    if (curl) {
        char *output = curl_easy_escape(curl, city.c_str(), city.length());
        if (output) {
            encodedCity = output;
            curl_free(output);
        }
        curl_easy_cleanup(curl);
    }

    std::string url = "https://nominatim.openstreetmap.org/search?q=" + encodedCity + "&format=json&limit=1&countrycodes=us";

    std::string jsonResponse = fetchUrl(url);

    if (jsonResponse.empty()) {
        return {};
    }

    try {
        json j = json::parse(jsonResponse);
        if (j.is_array() && !j.empty()) {
            json result = j[0];
            Coordinates coords;
            coords.latitude = std::stod(result["lat"].get<std::string>());
            coords.longitude = std::stod(result["lon"].get<std::string>());
            coords.displayName = result["display_name"].get<std::string>();
            return coords;
        }
    } catch (const json::parse_error& e) {
        std::cerr << "Error: Failed to parse Nominatim JSON response: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: An unexpected error occurred during coordinate processing: " << e.what() << std::endl;
    }

    return {};
}

// Step 2: Get NWS Forecast Grid URL
std::string getForecastUrl(double lat, double lon) {
    std::stringstream ss;
    ss << std::fixed << std::setprecision(4) << lat << "," << lon;
    std::string coords = ss.str();

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "--- 2. Calling NWS /points API for Lat/Lon: " << coords << " ---\n";

    std::string url = "https://api.weather.gov/points/" + coords;

    std::string jsonResponse = fetchUrl(url);

    if (jsonResponse.empty()) {
        return "";
    }

    try {
        json j = json::parse(jsonResponse);
        if (j.count("properties") && j["properties"].count("forecast")) {
            return j["properties"]["forecast"].get<std::string>();
        }
    } catch (const json::parse_error& e) {
        std::cerr << "Error: Failed to parse NWS points JSON response: " << e.what() << std::endl;
    }

    return "";
}

// Step 3: Fetch the Final Forecast Data
std::vector<ForecastPeriod> getForecast(const std::string& forecastUrl) {
    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "--- 3. Calling NWS Forecast API for: " << forecastUrl << " ---\n";
    std::vector<ForecastPeriod> periods;

    std::string jsonResponse = fetchUrl(forecastUrl);

    if (jsonResponse.empty()) {
        return periods;
    }

    try {
        json j = json::parse(jsonResponse);
        if (j.count("properties") && j["properties"].count("periods") && j["properties"]["periods"].is_array()) {
            for (const auto& p : j["properties"]["periods"]) {
                ForecastPeriod fp;
                fp.name = p["name"].get<std::string>();
                if (p.count("temperature") && p["temperature"].is_number_integer()) {
                    fp.temperature = p["temperature"].get<int>();
                } else {
                    fp.temperature = 999;
                }
                fp.detailedForecast = p["detailedForecast"].get<std::string>();
                fp.iconUrl = p["icon"].get<std::string>();
                periods.push_back(fp);
            }
        }
    } catch (const json::parse_error& e) {
        std::cerr << "Error: Failed to parse NWS forecast JSON response: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: An unexpected error occurred during forecast processing: " << e.what() << std::endl;
    }

    return periods;
}


// --- Main Application Logic ---
void fetchWeather() {
    // We no longer need the buffer clear here, as it's handled right after
    // reading the 'y/n' choice in main().

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "\nEnter a US City (e.g., Denver, CO or Miami, FL): ";
    std::string city;
    std::getline(std::cin, city);

    if (city.empty()) {
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cerr << "Error: City name cannot be empty.\n";
        return;
    }

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "\n\n--- Starting Real-Time Weather Fetch Process ---\n";

    Coordinates coords = getCityCoordinates(city);

    if (coords.latitude == 0.0 && coords.longitude == 0.0) {
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cerr << "Error: Could not find coordinates for '" << city << "'. Please check the city name and try again.\n";
        return;
    }

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "Successfully found coordinates:\n";
    std::cout << "  - Display Name: " << coords.displayName << "\n";
    std::cout << "  - Lat/Lon: " << std::fixed << std::setprecision(4) << coords.latitude << ", " << coords.longitude << "\n\n";

    std::string forecastUrl = getForecastUrl(coords.latitude, coords.longitude);

    if (forecastUrl.empty()) {
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cerr << "Error: National Weather Service did not return a forecast grid for these coordinates. (Check US territory coverage).\n";
        return;
    }

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "Successfully retrieved NWS Forecast URL: " << forecastUrl << "\n\n";

    std::vector<ForecastPeriod> forecast = getForecast(forecastUrl);

    if (forecast.empty()) {
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cerr << "Error: Could not retrieve a forecast for the specified location.\n";
        return;
    }

    // FIX: Replaced literal '/n' with correct escape sequence '\n'
    std::cout << "\n======================================================\n";
    std::cout << "   NWS Forecast for " << coords.displayName << "\n";
    std::cout << "======================================================\n";

    for (const auto& period : forecast) {
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cout << period.name << ":\n";
        if (period.temperature != 999) {
            // FIX: Replaced literal '/n' with correct escape sequence '\n'
            std::cout << "  - Temp: " << period.temperature << "°F\n";
        } else {
             // FIX: Replaced literal '/n' with correct escape sequence '\n'
             std::cout << "  - Temp: N/A\n";
        }
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cout << "  - Details: " << period.detailedForecast << "\n";
        // Removed: std::cout << "  - Icon URL: " << period.iconUrl << "\n";
        // FIX: Replaced literal '/n' with correct escape sequence '\n'
        std::cout << "------------------------------------------------------\n";
    }
}

int main() {
    curl_global_init(CURL_GLOBAL_ALL);
    char choice;

    // Start the loop for continuous use
    do {
        fetchWeather();

        // Ask the user if they want to run again
        std::cout << "\n\nFetch another forecast? (y/n): ";
        // Use operator>> to read a single character, skipping whitespace
        if (!(std::cin >> choice)) {
            // Handle EOF or read error gracefully
            choice = 'n';
            break;
        }

        // IMPORTANT: Clear the input buffer from the newline character left by operator>>
        // This ensures std::getline in fetchWeather() works correctly in the next iteration.
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // Convert choice to lowercase for case-insensitive check
        choice = std::tolower(choice);

    } while (choice == 'y');

    std::cout << "Exiting program. Thank you for using the NWS Weather Finder.\n";
    curl_global_cleanup();
    return 0;
}